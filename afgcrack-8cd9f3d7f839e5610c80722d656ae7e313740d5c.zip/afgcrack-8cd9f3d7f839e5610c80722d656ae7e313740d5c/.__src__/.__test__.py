import time
a = time.ctime()
print a